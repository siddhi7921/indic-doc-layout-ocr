"""IndicDocAI backend package."""
