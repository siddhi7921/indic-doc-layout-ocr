# IndicDocAI: Multilingual Document Layout & Structured OCR Engine

An end-to-end **Document AI pipeline** that converts complex, multi-column scanned documents (Indian regional newspapers, academic question papers, and forms in **Bengali, Hindi, and English**) into reading-order-preserving **Markdown** and **structured JSON**.

## Architecture

```text
Scanned Page ─▶ Layout Detector (DocLayout-YOLO / ONNX FP16)
                     │
                     ▼
        Augmented XY-Cut Reading-Order Sorter
                     │
                     ▼
     Script-Aware Crop OCR (Bengali / Hindi / English)
                     │
                     ▼
   React + TypeScript Human-in-the-Loop Verification Studio
```

## Key Features
- **Document Layout Detection (`ml/train_layout.py`)**: Fine-tunes YOLO layout weights on AI4Bharat's `IndicDLP` dataset (`Title`, `Text`, `Table`, `Figure`, `Caption`, `List`, `Header`, `Footer`, `Advertisement`).
- **ONNX Runtime Acceleration (`ml/export_onnx.py`)**: Exports PyTorch weights to `FP16` ONNX format and benchmarks inference latency (`ms/page`).
- **Augmented XY-Cut Reading Order (`backend/app/xy_cut.py`)**: Recursive 2D projection-profile splitting algorithm that restores natural human reading order across multi-column layouts before OCR.
- **Human-in-the-Loop Canvas (`frontend/src/App.tsx`)**: Interactive bounding-box visualizer with confidence threshold filtering (`< 0.80` flagged in amber), click-to-edit OCR blocks, and live Markdown/JSON export.

## Quick Start

### 1. Backend (FastAPI + ONNX + EasyOCR)
```bash
cd backend
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### 2. Frontend (React + TypeScript + Vite + Tailwind)
```bash
cd frontend
npm install
npm run dev
```

### 3. Model Fine-Tuning & Benchmarking
```bash
pip install ultralytics datasets onnxruntime jiwer
python ml/train_layout.py --epochs 30 --batch 16
python ml/export_onnx.py --weights runs/detect/indicdlp_layout/weights/best.pt
python ml/benchmark_cer.py --ground-truth sample_gt.txt --raw-ocr raw.txt --layout-ocr layout.txt
```
